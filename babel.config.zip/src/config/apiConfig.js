const API_BASE_URL = "https://localhost:8000/api"; // Backend base URL

export default API_BASE_URL;
