import React from "react";
import { Outlet } from "react-router-dom";
import AdminSidebar from "./Sidebar";
import AdminNavbar from "./NavBar";
import Footer from "../../compoents/footers";


const AdminLayout = () => {
  return (
    // <ThemeContextProvider>
      <div className="relative">
        <AdminNavbar />
        {/* Sidebar is fixed and should be placed below the navbar */}
        <AdminSidebar />
        {/* Main content area: add top margin to offset fixed navbar */}
        <div className="mt-7 ml-200 md:ml-20 transition-all duration-300">
          <Outlet />
        </div>
        {/* <Footer/> */}
      </div>
  
  );
};

export default AdminLayout;
